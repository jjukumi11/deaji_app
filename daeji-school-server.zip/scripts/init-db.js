import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';

const db = new Database('./data.sqlite');
db.pragma('journal_mode = WAL');
db.exec(`DELETE FROM users; DELETE FROM meals; DELETE FROM timetable; DELETE FROM assignments; DELETE FROM news;`);

const teacherHash = bcrypt.hashSync('teacher1234', 10);
const studentHash = bcrypt.hashSync('student1234', 10);

db.prepare('INSERT INTO users (email,passwordHash,name,role,classId) VALUES (?,?,?,?,?)')
  .run('teacher@daeji.hs.kr', teacherHash, '담임선생님', 'teacher', '1-3');

db.prepare('INSERT INTO users (email,passwordHash,name,role,classId) VALUES (?,?,?,?,?)')
  .run('student@daeji.hs.kr', studentHash, '홍길동', 'student', '1-3');

const weekdays = ['mon','tue','wed','thu','fri'];
for (const wd of weekdays) {
  const subjects = ['국어','수학','영어','과학','체육','음악'];
  db.prepare('INSERT INTO timetable (classId,weekday,subjects) VALUES (?,?,?)')
    .run('1-3', wd, JSON.stringify(subjects));
}

db.prepare('INSERT INTO news (classId,title,body,tag,date) VALUES (?,?,?,?,?)')
  .run('1-3','2학기 개학 안내','등교 08:30, 조회 08:40','공지', new Date().toISOString().slice(0,10));

console.log('Daeji HS DB initialized.');